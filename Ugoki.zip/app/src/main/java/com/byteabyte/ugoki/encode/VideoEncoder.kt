package com.byteabyte.ugoki.encode

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.Surface

private const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC

data class EncConfig(val w: Int, val h: Int, val fps: Int, val bitrate: Int)

enum class Quality(val label: String, val longSide: Int, val shortSide: Int) {
    HD("720p", 1280, 720),
    FHD("1080p", 1920, 1080),
    QHD("2K", 2560, 1440);

    fun w(vertical: Boolean) = if (vertical) shortSide else longSide
    fun h(vertical: Boolean) = if (vertical) longSide else shortSide
}

/**
 * Usa la calidad y los FPS elegidos. Si el chip no los soporta, baja primero a 30 FPS
 * y luego a la siguiente calidad inferior.
 */
object EncoderPicker {
    fun pick(quality: Quality, vertical: Boolean, fps: Int): EncConfig {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
            info.isEncoder && info.supportedTypes.any { it.equals(MIME, true) }
        }
        val qualities = Quality.entries.filter { it.ordinal <= quality.ordinal }.reversed()
        for (q in qualities) {
            val w = q.w(vertical)
            val h = q.h(vertical)
            for (f in listOf(fps, 30).distinct()) {
                for (info in infos) {
                    val caps = info.getCapabilitiesForType(MIME).videoCapabilities ?: continue
                    if (caps.isSizeSupported(w, h) && caps.areSizeAndRateSupported(w, h, f.toDouble())) {
                        val br = (w.toLong() * h * f * 12 / 100).toInt()
                        return EncConfig(w, h, f, caps.bitrateRange.clamp(br))
                    }
                }
            }
        }
        return EncConfig(Quality.HD.w(vertical), Quality.HD.h(vertical), 30, 8_000_000)
    }
}

/**
 * H.264 por Surface + MediaMuxer, guardando en Películas/Ugoki vía MediaStore.
 * Los timestamps se asignan por índice de frame (frame i → i/fps), así el MP4
 * sale a FPS exactos aunque el renderizado sea más lento que el tiempo real.
 */
class VideoEncoder(private val context: Context, private val cfg: EncConfig) {
    private val resolver = context.contentResolver
    private lateinit var codec: MediaCodec
    private lateinit var muxer: MediaMuxer
    private lateinit var surface: Surface
    private lateinit var pfd: ParcelFileDescriptor
    private lateinit var uri: Uri
    private lateinit var drainThread: Thread

    @Volatile private var aborted = false
    @Volatile private var error: Throwable? = null
    private var track = -1
    private var muxerStarted = false
    private var outIndex = 0L

    fun start(displayName: String) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Ugoki")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("No se pudo crear el archivo de salida")
        pfd = resolver.openFileDescriptor(uri, "rw") ?: error("No se pudo abrir el archivo de salida")
        muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val fmt = MediaFormat.createVideoFormat(MIME, cfg.w, cfg.h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, android.media.MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, cfg.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            setInteger(MediaFormat.KEY_BITRATE_MODE, android.media.MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
            setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
        }
        codec = MediaCodec.createEncoderByType(MIME)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        surface = codec.createInputSurface()
        codec.start()

        drainThread = Thread({ drainLoop() }, "ugoki-drain").also { it.start() }
    }

    /** Dibuja un frame en la superficie del codificador (hilo principal). */
    fun encodeFrame(draw: (Canvas) -> Unit) {
        error?.let { throw it }
        val canvas = surface.lockCanvas(null)
        try {
            draw(canvas)
        } finally {
            surface.unlockCanvasAndPost(canvas)
        }
    }

    private fun drainLoop() {
        val info = MediaCodec.BufferInfo()
        try {
            while (!aborted) {
                val idx = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    idx >= 0 -> {
                        val buf = codec.getOutputBuffer(idx)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && muxerStarted && buf != null) {
                            info.presentationTimeUs = outIndex * 1_000_000L / cfg.fps
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            muxer.writeSampleData(track, buf, info)
                            outIndex++
                        }
                        codec.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    }
                }
            }
        } catch (t: Throwable) {
            error = t
        }
    }

    fun finish(): Uri {
        codec.signalEndOfInputStream()
        drainThread.join(30_000)
        error?.let { abort(); throw it }
        runCatching { codec.stop() }
        codec.release()
        muxer.stop()
        muxer.release()
        pfd.close()
        surface.release()
        resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        return uri
    }

    fun abort() {
        aborted = true
        runCatching { drainThread.join(2_000) }
        runCatching { codec.stop() }
        runCatching { codec.release() }
        runCatching { muxer.release() }
        runCatching { pfd.close() }
        runCatching { surface.release() }
        runCatching { resolver.delete(uri, null, null) }
    }
}
