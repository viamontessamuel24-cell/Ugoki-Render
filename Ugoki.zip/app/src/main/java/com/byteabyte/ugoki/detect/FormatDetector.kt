package com.byteabyte.ugoki.detect

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

enum class Orientation { VERTICAL, HORIZONTAL }

data class Detection(
    val orientation: Orientation,
    val designW: Int,   // tamaño CSS con el que se renderiza la página
    val designH: Int,
    val durationMs: Long,
    val reason: String,
) {
    val vertical get() = orientation == Orientation.VERTICAL
    val outW get() = if (vertical) 1440 else 2560
    val outH get() = if (vertical) 2560 else 1440
    val label get() = if (vertical) "Vertical 9:16" else "Horizontal 16:9"
}

object FormatDetector {

    /** Decide formato y tamaño a partir de lo que midió detect.js en el DOM. */
    fun decide(raw: JSONObject, forced: Orientation?, manualSec: Double?): Detection {
        val w = raw.optDouble("w", 1920.0).coerceAtLeast(1.0)
        val h = raw.optDouble("h", 1080.0).coerceAtLeast(1.0)
        val source = raw.optString("source")

        val auto = when (raw.optString("forced")) {
            "v" -> Orientation.VERTICAL
            "h" -> Orientation.HORIZONTAL
            else -> if (h > w * 1.05) Orientation.VERTICAL else Orientation.HORIZONTAL
        }
        val o = forced ?: auto

        val target = if (o == Orientation.VERTICAL) 9.0 / 16.0 else 16.0 / 9.0
        val fits = w >= 300 && h >= 300 && abs((w / h) / target - 1.0) < 0.08
        val (dw, dh) = when {
            fits -> w.roundToInt() to h.roundToInt()
            o == Orientation.VERTICAL -> 1080 to 1920
            else -> 1920 to 1080
        }

        val detected = raw.optLong("durMs", 0L)
        val ms = when {
            manualSec != null && manualSec > 0 -> (manualSec * 1000).toLong()
            detected > 0 -> detected
            else -> 10_000L
        }.coerceIn(1_000L, 300_000L)

        val reason = when {
            forced != null -> "elegido manualmente"
            raw.optString("forced").isNotEmpty() -> "meta ugoki-format"
            source == "element" -> "escenario ${w.roundToInt()}×${h.roundToInt()}"
            source == "aspect-ratio" -> "CSS aspect-ratio"
            source == "scroll" -> "tamaño del contenido"
            else -> "tamaño de la ventana"
        }
        return Detection(o, dw, dh, ms, reason)
    }
}
