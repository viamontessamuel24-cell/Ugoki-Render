package com.byteabyte.ugoki.ui

import android.net.Uri
import com.byteabyte.ugoki.detect.Orientation
import com.byteabyte.ugoki.encode.Quality
import org.json.JSONObject

enum class Mode(val orientation: Orientation?, val label: String) {
    AUTO(null, "Auto"),
    VERTICAL(Orientation.VERTICAL, "9:16"),
    HORIZONTAL(Orientation.HORIZONTAL, "16:9"),
}

data class UiState(
    val fileUri: Uri? = null,
    val fileName: String? = null,
    val probe: JSONObject? = null,
    val mode: Mode = Mode.AUTO,
    val quality: Quality = Quality.QHD,
    val fps: Int = 60,
    val durationText: String = "",
    val busy: Boolean = false,
    val progress: Float = 0f,
    val status: String = "",
    val outputUri: Uri? = null,
    val error: String? = null,
)
