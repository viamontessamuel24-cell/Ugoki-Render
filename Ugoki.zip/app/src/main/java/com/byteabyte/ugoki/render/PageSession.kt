package com.byteabyte.ugoki.render

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.view.doOnLayout
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.roundToInt

/**
 * Una página HTML cargada en un WebView con reloj virtual.
 * El WebView mide (cssW × cssH) píxeles CSS y está debajo de la UI (oculto por ella).
 */
class PageSession(private val activity: Activity, private val host: ViewGroup) {

    private lateinit var wv: WebView
    var viewW = 0; private set
    var viewH = 0; private set
    private var vsId = 0L

    private val clockJs by lazy { asset("ugoki_clock.js") }
    val detectJs by lazy { asset("ugoki_detect.js") }

    private fun asset(name: String) =
        activity.assets.open(name).bufferedReader().use { it.readText() }

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun open(html: String, cssW: Int, cssH: Int) {
        val density = activity.resources.displayMetrics.density
        viewW = (cssW * density).roundToInt()
        viewH = (cssH * density).roundToInt()

        val loaded = CompletableDeferred<Unit>()
        wv = WebView(activity).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.useWideViewPort = false
            settings.loadWithOverviewMode = false
            settings.textZoom = 100
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.minimumFontSize = 1
            settings.minimumLogicalFontSize = 1
            setBackgroundColor(Color.WHITE)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    loaded.complete(Unit)
                }
            }
        }
        host.addView(wv, FrameLayout.LayoutParams(viewW, viewH))
        suspendCancellableCoroutine<Unit> { c -> wv.doOnLayout { if (c.isActive) c.resume(Unit) } }

        wv.loadDataWithBaseURL("https://ugoki.local/", inject(html), "text/html", "UTF-8", null)
        withTimeout(30_000) { loaded.await() }
        delay(500)

        var n = 0
        while (n < 20 && eval("document.fonts ? document.fonts.status : 'loaded'") != "\"loaded\"") {
            delay(150); n++
        }
        step(0.0)
    }

    private fun inject(html: String): String {
        val payload = "<style>html,body{margin:0!important;overflow:hidden!important}" +
            "*,*::before,*::after{animation-play-state:paused!important}</style>" +
            "<script>$clockJs</script>"
        val head = Regex("<head(\\s[^>]*)?>", RegexOption.IGNORE_CASE).find(html)
        if (head != null) return html.substring(0, head.range.last + 1) + payload + html.substring(head.range.last + 1)
        val root = Regex("<html(\\s[^>]*)?>", RegexOption.IGNORE_CASE).find(html)
        if (root != null) return html.substring(0, root.range.last + 1) + payload + html.substring(root.range.last + 1)
        return "<!DOCTYPE html>$payload$html"
    }

    suspend fun eval(js: String): String = suspendCancellableCoroutine { c ->
        wv.evaluateJavascript(js) { if (c.isActive) c.resume(it ?: "null") }
    }

    /** Avanza el reloj virtual y espera a que el WebView tenga el DOM listo para dibujar. */
    suspend fun step(ms: Double) {
        eval("window.__ugoki.step($ms)")
        awaitVisualState()
    }

    private suspend fun awaitVisualState() {
        withTimeoutOrNull(1_500) {
            suspendCancellableCoroutine<Unit> { c ->
                wv.postVisualStateCallback(++vsId, object : WebView.VisualStateCallback() {
                    override fun onComplete(requestId: Long) {
                        if (c.isActive) c.resume(Unit)
                    }
                })
            }
        }
    }

    fun drawTo(canvas: Canvas, scale: Float, dx: Float, dy: Float) {
        canvas.save()
        canvas.translate(dx, dy)
        canvas.scale(scale, scale)
        wv.draw(canvas)
        canvas.restore()
    }

    fun close() {
        if (!::wv.isInitialized) return
        host.removeView(wv)
        wv.stopLoading()
        wv.destroy()
    }
}
