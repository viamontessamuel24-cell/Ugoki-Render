package com.byteabyte.ugoki.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.byteabyte.ugoki.detect.Detection
import com.byteabyte.ugoki.encode.Quality

private val Bg = Color(0xFF0B0B12)
private val Surf = Color(0xFF151522)
private val Purple = Color(0xFF8B5CF6)
private val PurpleDim = Color(0xFF2A1F4D)
private val TextC = Color(0xFFEDEAF7)
private val Muted = Color(0xFF8B87A0)
private val Danger = Color(0xFFFF6B81)

@Composable
fun UgokiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, onPrimary = Color.White,
            background = Bg, onBackground = TextC,
            surface = Surf, onSurface = TextC,
            surfaceVariant = Surf, outline = PurpleDim,
        ),
        content = content,
    )
}

@Composable
fun HomeScreen(
    ui: UiState,
    det: Detection?,
    onPick: () -> Unit,
    onMode: (Mode) -> Unit,
    onQuality: (Quality) -> Unit,
    onFps: (Int) -> Unit,
    onDuration: (String) -> Unit,
    onRender: () -> Unit,
    onCancel: () -> Unit,
    onOpen: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Ugoki", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Purple)
        Text("Animaciones HTML → MP4 en 2K", color = Muted)

        DropZone(ui.fileName, !ui.busy, onPick)

        if (det != null) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surf).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    "${det.label}  →  ${ui.quality.w(det.vertical)}×${ui.quality.h(det.vertical)} · ${ui.fps} FPS",
                    color = TextC, fontWeight = FontWeight.SemiBold,
                )
                Text("Escenario ${det.designW}×${det.designH} · ${det.reason}", color = Muted, fontSize = 13.sp)
                Text("Duración: ${"%.1f".format(det.durationMs / 1000.0)} s", color = Muted, fontSize = 13.sp)
            }
        }

        if (ui.fileUri != null) {
            Text("Formato", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mode.entries.forEach { m ->
                    FilterChip(
                        selected = ui.mode == m,
                        onClick = { onMode(m) },
                        label = { Text(m.label) },
                        enabled = !ui.busy,
                    )
                }
            }
            Text("Calidad", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Quality.entries.forEach { q ->
                    FilterChip(
                        selected = ui.quality == q,
                        onClick = { onQuality(q) },
                        label = { Text(q.label) },
                        enabled = !ui.busy,
                    )
                }
            }
            Text("FPS", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60).forEach { f ->
                    FilterChip(
                        selected = ui.fps == f,
                        onClick = { onFps(f) },
                        label = { Text("$f FPS") },
                        enabled = !ui.busy,
                    )
                }
            }
            OutlinedTextField(
                value = ui.durationText,
                onValueChange = onDuration,
                label = { Text("Duración en segundos (vacío = auto)") },
                singleLine = true,
                enabled = !ui.busy,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Button(
            onClick = onRender,
            enabled = ui.probe != null && !ui.busy,
            modifier = Modifier.fillMaxWidth().height(54.dp),
        ) { Text("Renderizar Video", fontWeight = FontWeight.Bold) }

        if (ui.busy) {
            if (ui.progress > 0f) {
                LinearProgressIndicator(
                    progress = { ui.progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = Purple, trackColor = PurpleDim,
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = Purple, trackColor = PurpleDim,
                )
            }
            TextButton(onClick = onCancel) { Text("Cancelar", color = Danger) }
        }

        if (ui.status.isNotEmpty()) Text(ui.status, color = Muted, fontSize = 13.sp)
        ui.error?.let { Text(it, color = Danger, fontSize = 13.sp) }
        if (ui.outputUri != null) {
            Button(onClick = onOpen, modifier = Modifier.fillMaxWidth()) { Text("Ver video") }
        }
    }
}

@Composable
private fun DropZone(fileName: String?, enabled: Boolean, onPick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Surf)
            .drawBehind {
                drawRoundRect(
                    color = Purple,
                    style = Stroke(
                        width = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f)),
                    ),
                    cornerRadius = CornerRadius(40f, 40f),
                )
            }
            .clickable(enabled = enabled) { onPick() },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(fileName ?: "Toca para elegir un archivo .html", color = TextC, fontWeight = FontWeight.SemiBold)
            if (fileName == null) Text("o compártelo hacia Ugoki", color = Muted, fontSize = 13.sp)
        }
    }
}
