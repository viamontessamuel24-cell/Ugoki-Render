package com.byteabyte.ugoki

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.lifecycleScope
import com.byteabyte.ugoki.detect.FormatDetector
import com.byteabyte.ugoki.render.UgokiEngine
import com.byteabyte.ugoki.ui.HomeScreen
import com.byteabyte.ugoki.ui.UgokiTheme
import com.byteabyte.ugoki.ui.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var ui by mutableStateOf(UiState())
    private lateinit var host: FrameLayout
    private lateinit var engine: UgokiEngine
    private var html: String? = null
    private var job: Job? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadFile(uri)
    }

    private fun durationOf(s: UiState) = s.durationText.replace(',', '.').toDoubleOrNull()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // El WebView vive en `host`, debajo de la UI (que es opaca y lo tapa).
        host = FrameLayout(this)
        engine = UgokiEngine(this, host)

        val compose = ComposeView(this).apply {
            setContent {
                UgokiTheme {
                    val det = ui.probe?.let {
                        FormatDetector.decide(it, ui.mode.orientation, durationOf(ui))
                    }
                    HomeScreen(
                        ui = ui,
                        det = det,
                        onPick = { picker.launch(arrayOf("text/html", "text/*", "application/xhtml+xml")) },
                        onMode = { ui = ui.copy(mode = it) },
                        onQuality = { ui = ui.copy(quality = it) },
                        onFps = { ui = ui.copy(fps = it) },
                        onDuration = { ui = ui.copy(durationText = it) },
                        onRender = ::startRender,
                        onCancel = { job?.cancel() },
                        onOpen = ::openVideo,
                    )
                }
            }
        }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        setContentView(FrameLayout(this).apply {
            addView(host, FrameLayout.LayoutParams(match, match))
            addView(compose, FrameLayout.LayoutParams(match, match))
        })

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        val uri: Uri? = when (i?.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> i.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
            else -> null
        }
        if (uri != null) loadFile(uri)
    }

    private fun nameOf(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) c.getString(col) else null
        } ?: "animacion.html"

    private fun loadFile(uri: Uri) {
        job?.cancel()
        val text = runCatching {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        }.getOrNull()
        if (text == null) {
            ui = ui.copy(error = "No se pudo leer el archivo")
            return
        }
        html = text
        ui = UiState(
            fileUri = uri, fileName = nameOf(uri), mode = ui.mode,
            quality = ui.quality, fps = ui.fps,
            busy = true, status = "Analizando animación…",
        )
        job = lifecycleScope.launch {
            try {
                val raw = engine.analyze(text)
                ui = ui.copy(probe = raw, busy = false, status = "Listo para renderizar")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                ui = ui.copy(busy = false, status = "", error = "Error al analizar: ${e.message ?: e}")
            }
        }
    }

    private fun startRender() {
        val text = html ?: return
        val probe = ui.probe ?: return
        val det = FormatDetector.decide(probe, ui.mode.orientation, durationOf(ui))
        val base = "Ugoki_" +
            (ui.fileName ?: "video").substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_") + "_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ui = ui.copy(busy = true, progress = 0f, outputUri = null, error = null, status = "Preparando…")
        job = lifecycleScope.launch {
            try {
                val out = engine.render(text, det, ui.quality, ui.fps, base) { p, msg -> ui = ui.copy(progress = p, status = msg) }
                ui = ui.copy(busy = false, progress = 1f, outputUri = out, status = "¡Listo! Guardado en Películas/Ugoki")
            } catch (e: CancellationException) {
                ui = ui.copy(busy = false, progress = 0f, status = "Cancelado")
                throw e
            } catch (e: Throwable) {
                ui = ui.copy(busy = false, progress = 0f, status = "", error = "Error: ${e.message ?: e}")
            } finally {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    private fun openVideo() {
        val uri = ui.outputUri ?: return
        startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
