package com.byteabyte.ugoki.render

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.SystemClock
import android.view.ViewGroup
import com.byteabyte.ugoki.detect.Detection
import com.byteabyte.ugoki.encode.EncoderPicker
import com.byteabyte.ugoki.encode.Quality
import com.byteabyte.ugoki.encode.VideoEncoder
import kotlinx.coroutines.yield
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

class UgokiEngine(private val activity: Activity, private val host: ViewGroup) {

    /** Paso 1: carga el HTML y mide el DOM (tamaño del escenario, duración, meta tags). */
    suspend fun analyze(html: String): JSONObject {
        val s = PageSession(activity, host)
        try {
            s.open(html, 1920, 1080)
            val raw = s.eval(s.detectJs)
            val text = JSONTokener(raw).nextValue() as? String ?: raw
            return JSONObject(text)
        } finally {
            s.close()
        }
    }

    /** Paso 2: renderiza frame a frame y codifica a MP4. Devuelve el Uri del video. */
    suspend fun render(
        html: String,
        det: Detection,
        quality: Quality,
        fps: Int,
        baseName: String,
        onProgress: (Float, String) -> Unit,
    ): Uri {
        val cfg = EncoderPicker.pick(quality, det.vertical, fps)
        val adjusted = cfg.fps != fps || cfg.w != quality.w(det.vertical)
        val note = if (adjusted) " · ajustado a lo que soporta tu chip" else ""
        onProgress(0f, "Cargando animación…")
        val s = PageSession(activity, host)
        var enc: VideoEncoder? = null
        try {
            s.open(html, det.designW, det.designH)

            val scale = min(cfg.w / s.viewW.toFloat(), cfg.h / s.viewH.toFloat())
            val dx = (cfg.w - s.viewW * scale) / 2f
            val dy = (cfg.h - s.viewH * scale) / 2f
            val total = max(1, ceil(det.durationMs / 1000.0 * cfg.fps).toInt())
            val dt = 1000.0 / cfg.fps

            enc = VideoEncoder(activity, cfg).also { it.start(baseName) }
            val t0 = SystemClock.elapsedRealtime()

            for (i in 0 until total) {
                if (i > 0) s.step(dt)
                enc.encodeFrame { c ->
                    c.drawColor(Color.WHITE)
                    s.drawTo(c, scale, dx, dy)
                }
                val done = i + 1
                val elapsed = (SystemClock.elapsedRealtime() - t0) / 1000.0
                val eta = (elapsed / done * (total - done)).toInt()
                onProgress(
                    done / total.toFloat(),
                    "${cfg.w}×${cfg.h} · ${cfg.fps} FPS — frame $done/$total (≈ ${eta}s restantes)$note",
                )
                yield()
            }
            val uri = enc.finish()
            enc = null
            return uri
        } finally {
            enc?.abort()
            s.close()
        }
    }
}
