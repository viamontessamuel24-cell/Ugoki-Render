// Reloj virtual de Ugoki: congela el tiempo y lo avanza frame a frame.
(function () {
  if (window.__ugoki) return;
  var now = 0, RD = Date, T0 = RD.now();
  var cbs = new Map(), rid = 1, timers = new Map(), tid = 1;

  function FD() {
    var a = Array.prototype.slice.call(arguments);
    if (!(this instanceof FD)) return new RD(T0 + now).toString();
    if (a.length === 0) return new RD(T0 + now);
    return new (Function.prototype.bind.apply(RD, [null].concat(a)))();
  }
  FD.prototype = RD.prototype;
  FD.now = function () { return T0 + now; };
  FD.UTC = RD.UTC;
  FD.parse = RD.parse;
  window.Date = FD;

  performance.now = function () { return now; };

  window.requestAnimationFrame = function (cb) { var id = rid++; cbs.set(id, cb); return id; };
  window.cancelAnimationFrame = function (id) { cbs.delete(id); };

  window.setTimeout = function (fn, ms) {
    var args = Array.prototype.slice.call(arguments, 2), id = tid++;
    timers.set(id, { fn: fn, at: now + Math.max(1, +ms || 0), rep: 0, args: args });
    return id;
  };
  window.setInterval = function (fn, ms) {
    var args = Array.prototype.slice.call(arguments, 2), id = tid++, r = Math.max(1, +ms || 0);
    timers.set(id, { fn: fn, at: now + r, rep: r, args: args });
    return id;
  };
  window.clearTimeout = window.clearInterval = function (id) { timers.delete(id); };

  function syncAnims(prev) {
    var list = [];
    try { list = document.getAnimations(); } catch (e) {}
    list.forEach(function (a) {
      try {
        if (a.__u === undefined) { a.__u = prev; a.pause(); }
        a.currentTime = now - a.__u;
      } catch (e) {}
    });
  }

  function step(dt) {
    var prev = now, target = now + dt;
    for (;;) {
      var bk = null, bt = null;
      timers.forEach(function (t, k) {
        if (t.at <= target && (bt === null || t.at < bt.at)) { bt = t; bk = k; }
      });
      if (bt === null) break;
      now = Math.max(now, bt.at);
      if (bt.rep > 0) bt.at += bt.rep; else timers.delete(bk);
      try { if (typeof bt.fn === 'function') bt.fn.apply(window, bt.args); } catch (e) {}
    }
    now = target;
    syncAnims(prev);
    var list = [];
    cbs.forEach(function (cb) { list.push(cb); });
    cbs.clear();
    list.forEach(function (cb) { try { cb(now); } catch (e) {} });
    return now;
  }

  window.__ugoki = { step: step, now: function () { return now; } };
})();
