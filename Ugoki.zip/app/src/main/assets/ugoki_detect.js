(function () {
  var out = { vw: innerWidth, vh: innerHeight, w: innerWidth, h: innerHeight, source: 'viewport', forced: '', durMs: 0 };

  function arOf(cs) {
    var s = cs.aspectRatio;
    if (!s || s === 'auto') return 0;
    var p = s.split('/');
    var a = parseFloat(p[0]), b = p.length > 1 ? parseFloat(p[1]) : 1;
    return (a > 0 && b > 0) ? a / b : 0;
  }

  // Override manual opcional: <meta name="ugoki-format" content="9:16">
  var m = document.querySelector('meta[name="ugoki-format"]');
  if (m) {
    var c = (m.content || '').toLowerCase().replace(/\s/g, '');
    if (c === '9:16' || c === 'vertical') out.forced = 'v';
    else if (c === '16:9' || c === 'horizontal') out.forced = 'h';
  }

  // 1) Elemento "escenario" más grande dentro del body
  var best = null, area = 0;
  Array.prototype.forEach.call(document.body.children, function (el) {
    if (/^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) return;
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return;
    var r = el.getBoundingClientRect(), w = r.width, h = r.height, ar = arOf(cs);
    if (ar && h > 0 && Math.abs(w / h - ar) > 0.02) h = w / ar;
    if (w >= 200 && h >= 200 && w * h > area) { area = w * h; best = { w: w, h: h }; }
  });
  if (best) { out.w = best.w; out.h = best.h; out.source = 'element'; }
  else {
    // 2) aspect-ratio en body / html
    var ar0 = arOf(getComputedStyle(document.body)) || arOf(getComputedStyle(document.documentElement));
    if (ar0) { out.w = innerWidth; out.h = innerWidth / ar0; out.source = 'aspect-ratio'; }
    else {
      // 3) tamaño del contenido
      var d = document.documentElement, b = document.body;
      var sw = Math.max(d.scrollWidth, b.scrollWidth), sh = Math.max(d.scrollHeight, b.scrollHeight);
      if (sw > 0 && sh > 0) { out.w = sw; out.h = sh; out.source = 'scroll'; }
    }
  }

  // Duración
  var dur = 0;
  try {
    document.getAnimations().forEach(function (a) {
      var t = a.effect && a.effect.getComputedTiming();
      if (!t) return;
      var e = isFinite(t.endTime) ? t.endTime : ((t.delay || 0) + (typeof t.duration === 'number' ? t.duration : 0));
      if (e > dur) dur = e;
    });
  } catch (e) {}
  try {
    if (window.gsap && gsap.globalTimeline) {
      var g = gsap.globalTimeline.duration();
      if (isFinite(g) && g > 0 && g < 600) dur = Math.max(dur, g * 1000);
    }
  } catch (e) {}
  var md = document.querySelector('meta[name="ugoki-duration"]');
  if (md && parseFloat(md.content) > 0) dur = parseFloat(md.content) * 1000;
  if (typeof window.__ugokiDuration === 'number') dur = window.__ugokiDuration * 1000;
  out.durMs = Math.round(dur);

  return JSON.stringify(out);
})()
