# Ugoki

App Android (Kotlin + Jetpack Compose) que convierte animaciones HTML/CSS/JS en MP4 2K.

## Compilar en GitHub
1. Sube todo este proyecto a un repositorio (incluida la carpeta `.github/workflows/build.yml`).
2. Pestaña **Actions** → workflow **Build APK** (corre solo con cada push).
3. Al terminar, descarga el artefacto **Ugoki-debug-apk** e instala el APK.

## Notas para tus HTML
- Un solo archivo .html (CSS y JS dentro). Librerías por CDN https (GSAP, etc.) funcionan con internet.
- Override opcional en `<head>`:
  - `<meta name="ugoki-format" content="9:16">` (o `16:9`)
  - `<meta name="ugoki-duration" content="8">` (segundos)
- Eliges calidad (720p / 1080p / 2K) y FPS (30 / 60). Si el chip no soporta lo elegido, baja primero a 30 FPS y luego a la calidad inferior.
- Salida: Películas/Ugoki.
